package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}	
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
	private static final String CIPHER = "SHA-256";
	private static final String NAME = "Yuriy Kuptsov";
	
	private String bytesToHex(byte[] data) {
		String output = "";
		
		for (int i = 0; i < data.length; i++) {			
			output += Integer.toString(Byte.toUnsignedInt(data[i]), 16);
		}
		
		return output;
	}
	
    @RequestMapping("/hash")
    public String myHash(){
    	String data = NAME;
    	String greeting = "Hello " + NAME + "!";
    	byte[] encyptedDataAsString = new byte[0];

		try {
	    	MessageDigest md = MessageDigest.getInstance(CIPHER);
			byte[] encrypted = md.digest(data.getBytes(StandardCharsets.UTF_8));
			encyptedDataAsString = encrypted;
		} catch (NoSuchAlgorithmException nsae) {
			System.out.println("Algorithm " + CIPHER + " was not found.");
		}
       
        return "<p>" + greeting + "</p><p>Cipher: " + CIPHER + "</p><p>hash: " + bytesToHex(encyptedDataAsString) + "</p>";
    }
}
	